﻿
namespace Mapper
{
    public enum ParentType
    {
        Rooms,
        Labels,
        Background,
    }
}
