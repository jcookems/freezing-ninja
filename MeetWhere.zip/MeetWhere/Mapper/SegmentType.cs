﻿
namespace Mapper
{
    public enum SegmentType
    {
        Move,
        Line,
        Arc,
        Close
    }
}
