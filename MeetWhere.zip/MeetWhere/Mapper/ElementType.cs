﻿
namespace Mapper
{
    public enum ElementType
    {
        Circle,
        Path,
        Text,
    }
}
