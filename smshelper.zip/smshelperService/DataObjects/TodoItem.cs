﻿using Microsoft.WindowsAzure.Mobile.Service;

namespace smshelperService.DataObjects
{
    public class TodoItem : EntityData
    {
        public string Text { get; set; }

        public bool Complete { get; set; }
    }
}